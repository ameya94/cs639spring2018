package com.pace.cs639spring.hw1;

import android.graphics.Color;
import android.graphics.PorterDuff;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    int animal_click=0;
    ImageView mbird_iv ;
    ImageView mcat_iv ;
    ImageView mdog_iv ;

    View mred_color ;
    View myellow_color ;
    View mgreen_color ;
    View mgray_color ;
    View mblue_color;

    TextView mbird_description;
    TextView mcat_description;
    TextView mdog_description;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        mbird_iv = findViewById(R.id.bird_iv);
        mcat_iv = findViewById(R.id.cat_iv);
        mdog_iv = findViewById(R.id.dog_iv);
        mred_color = findViewById(R.id.red_color);
        myellow_color = findViewById(R.id.yellow_color);
        mgreen_color = findViewById(R.id.green_color);
        mgray_color = findViewById(R.id.gray_color);
        mblue_color = findViewById(R.id.blue_color);

        mbird_description=findViewById(R.id.bird_tv);
        mdog_description = findViewById(R.id.dog_tv);
        mcat_description=findViewById(R.id.cat_tv);

        mbird_iv.setOnClickListener(this);
        mcat_iv.setOnClickListener(this);
        mdog_iv.setOnClickListener(this);
        mred_color.setOnClickListener(this);
        myellow_color.setOnClickListener(this);
        mgreen_color.setOnClickListener(this);
        mgray_color.setOnClickListener(this);
        mblue_color.setOnClickListener(this);

    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }

    @Override
    public void onClick(View v) {
        paint(v);
    }

    private void paint(View v) {
        if(v instanceof ImageView){
            if (v==mbird_iv) {
                animal_click=1;
                mbird_description.setVisibility(View.VISIBLE);
                mcat_description.setVisibility(View.INVISIBLE);
                mdog_description.setVisibility(View.INVISIBLE);
            }
            if (v==mcat_iv) {
                animal_click=2;
                mcat_description.setVisibility(View.VISIBLE);
                mdog_description.setVisibility(View.INVISIBLE);
                mbird_description.setVisibility(View.INVISIBLE);
            }
            if (v==mdog_iv) {
                animal_click=3;
                mdog_description.setVisibility(View.VISIBLE);
                mcat_description.setVisibility(View.INVISIBLE);
                mbird_description.setVisibility(View.INVISIBLE);
            }
        }
        else {
            if (animal_click==0){
                    Toast.makeText(getApplicationContext(), "Select an image before choosing color ", Toast.LENGTH_LONG).show();
            }
            else if (v==mred_color) {
                if(animal_click==1)
                {
                    mbird_iv.setColorFilter(Color.RED, PorterDuff.Mode.SRC_IN);
                }
                else if(animal_click==2)
                {
                    mcat_iv.setColorFilter(Color.RED,PorterDuff.Mode.SRC_IN);

                }
                else if(animal_click==3)
                {
                    mdog_iv.setColorFilter(Color.RED,PorterDuff.Mode.SRC_IN);

                }
            }
            else if (v==mgreen_color) {
                if(animal_click==1)
                {
                    mbird_iv.setColorFilter(Color.GREEN,PorterDuff.Mode.SRC_IN);

                }
                else if(animal_click==2)
                {
                    mcat_iv.setColorFilter(Color.GREEN,PorterDuff.Mode.SRC_IN);
                }
                else if(animal_click==3)
                {
                    mdog_iv.setColorFilter(Color.GREEN,PorterDuff.Mode.SRC_IN);
                }

            }
            else if (v==mblue_color) {
                if(animal_click==1)
                {
                    mbird_iv.setColorFilter(Color.BLUE,PorterDuff.Mode.SRC_IN);
                }
                else if(animal_click==2)
                {
                    mcat_iv.setColorFilter(Color.BLUE,PorterDuff.Mode.SRC_IN);
                }
                else if(animal_click==3)
                {
                    mdog_iv.setColorFilter(Color.BLUE,PorterDuff.Mode.SRC_IN);
                }
            }
            else if (v==myellow_color) {
                if(animal_click==1)
                {
                    mbird_iv.setColorFilter(Color.YELLOW,PorterDuff.Mode.SRC_IN);
                }
                else if(animal_click==2)
                {
                    mcat_iv.setColorFilter(Color.YELLOW,PorterDuff.Mode.SRC_IN);
                }
                else if(animal_click==3)
                {
                    mdog_iv.setColorFilter(Color.YELLOW,PorterDuff.Mode.SRC_IN);
                }
            }
            else if (v==mgray_color) {
                if(animal_click==1)
                {
                    mbird_iv.setColorFilter(Color.GRAY,PorterDuff.Mode.SRC_IN);
                }
                else if(animal_click==2)
                {
                    mcat_iv.setColorFilter(Color.GRAY,PorterDuff.Mode.SRC_IN);
                }
                else if(animal_click==3)
                {
                    mdog_iv.setColorFilter(Color.GRAY,PorterDuff.Mode.SRC_IN);
                }
            }

        }
    }
}

